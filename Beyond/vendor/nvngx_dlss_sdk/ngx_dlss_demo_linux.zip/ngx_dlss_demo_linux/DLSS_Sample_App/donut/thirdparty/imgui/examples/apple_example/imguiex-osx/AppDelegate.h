//
//  AppDelegate.h
//  imguiex-osx
//
//  Created by James Chen on 4/5/16.
//  Copyright © 2016 Joel Davis. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

