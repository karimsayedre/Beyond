/*
 * SPDX-FileCopyrightText: Copyright (c) 2018-2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */
#pragma once

#include <donut/core/log.h>

#include <cstdint>
#include <memory>
#include <vector>
#include <string>

namespace donut::vfs
{
    class IBlob;
}

//
// Low-level Chunk file API
//

namespace donut::chunk
{



//
// chunkId : unique chunk identifier in a file
//

class ChunkId {

public:

    ChunkId() : _chunkId(INVALID_CHUNK_ID) {}

    bool valid() const { return _chunkId!=INVALID_CHUNK_ID; }

    bool operator == (ChunkId const & other) const { return _chunkId==other._chunkId; }

private:

    friend class ChunkFile;

    ChunkId(uint32_t id) : _chunkId(id) {}

    static constexpr uint32_t const INVALID_CHUNK_ID = ~uint32_t(0);

    uint32_t _chunkId;
};



//
// Chunk : individual chunk descriptor
//
struct Chunk
{
    ChunkId chunkId;        // chunk unique ID in file/blob

    uint32_t chunkType,     // note : chunkType is not enum typed because ChunkFile
             chunkVersion;  // is agnostic to actual chunk types

    size_t offset,          // offset of chunk in file/blob
           size;            // size of chunk user data (in bytes)

    void const * data;      // chunk user data
};

//
// ChunkFile
//

class ChunkFile
{

public:

    // deserialization interface

    static std::shared_ptr<ChunkFile const> deserialize(
        std::weak_ptr<donut::vfs::IBlob const> blobPtr, char const * filepath);

    std::string const & getFilePath() const { return _filepath; }

public:

    // serialization interface

    std::shared_ptr<donut::vfs::IBlob const> serialize() const;

    template <typename ChunkDesc> ChunkId addChunk(void const * data, size_t size);

    void reset();

public:

    // general chunk access interface

    auto const & getChunks() const { return _chunks; }

    Chunk const * getChunk(ChunkId chunkId) const;

    void getChunks(uint32_t chunkType, std::vector<Chunk const *> & result) const;

    template <typename ChunkDesc> Chunk const * getChunk(ChunkId chunkId) const;

    template <typename ChunkDesc> bool validateChunk(Chunk const * chunk) const;

private:

    struct Header;

    struct ChunkTableEntry;

    ChunkId addChunk(uint32_t type, uint32_t version, void const * data, size_t size);

    std::string _filepath;

    std::vector<std::unique_ptr<Chunk const>> _chunks;

    std::shared_ptr<donut::vfs::IBlob const> _data;
};



//
// Implementation
//

template <typename ChunkDesc> ChunkId ChunkFile::addChunk(void const * data, size_t size)
{
    return addChunk(ChunkDesc::chunktype, ChunkDesc::version, data, size);
}

template <typename ChunkDesc> Chunk const * ChunkFile::getChunk(ChunkId chunkId) const
{
    if (!chunkId.valid())
    {
        log::error("chunkId (%d) not valid");
        return nullptr;
    }
    if (auto const chunk = getChunk(chunkId))
        return validateChunk<ChunkDesc>(chunk) ? chunk : nullptr;
    else
        log::error("chunk (%d) not found");
    return nullptr;
}

template <typename ChunkDesc> bool ChunkFile::validateChunk(Chunk const * chunk) const
{
    if (!chunk)
        return false;

    if (chunk->chunkType!=ChunkDesc::chunktype)
    {
        log::error("chunk (%d) : wrong type %d (expected %d)",
            chunk->chunkId, chunk->chunkType, ChunkDesc::chunktype);
        return false;
    }
    if (chunk->chunkVersion!=ChunkDesc::version) {
        log::error("chunk (%d) : wrong version %d (expected %d)",
            chunk->chunkId, chunk->chunkVersion, ChunkDesc::version);
        return false;
    }
    if (chunk->size==0 || chunk->data==nullptr)
    {
        log::error("no data in chunk (%d)", chunk->chunkId);
        return false;
    }
    return true;
}

}
