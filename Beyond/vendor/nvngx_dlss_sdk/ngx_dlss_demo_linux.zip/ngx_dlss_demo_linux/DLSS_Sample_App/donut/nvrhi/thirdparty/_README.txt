To install StackWalker for Windows stack traces, execute the equivalent in the nvrhi/thirdparty folder:

git clone https://github.com/JochenKalmbach/StackWalker.git

The web page for the library is:
	https://github.com/JochenKalmbach/StackWalker